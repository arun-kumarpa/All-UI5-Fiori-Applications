jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/UIComponent",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/MessageBox",
	"masterLeaseAgreement/zMaster_Lease_Agreement/model/formatter",
	"sap/ui/model/FilterOperator"
], function (Controller, Filter, Sorter, JSONModel, MessageToast, UIComponent, Dialog, Button, ButtonType, MessageBox, formatter,
	FilterOperator) {
	"use strict";
	var sFlag = false;
	return Controller.extend("masterLeaseAgreement.zMaster_Lease_Agreement.controller.Master_Agreement", {
		formatter: formatter,
		onInit: function () {
			var JSonModel = new sap.ui.model.json.JSONModel();
			var HrdJSonModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(HrdJSonModel, "HEADER");
			JSonModel.setData({
				isVisibleLease: true,
				isVisibleCrLease: false,
				isEnableLease: true,
				isEnableLeaseItem: true,
				ValueHelpSet: ""
			});
			this.getView().setModel(JSonModel, "lVisEnb");

			this.fuHeaderDetails();
			//this.fnLeaseDetails();
			//this.fnCompanyCodeDetails();
			/*Model.read("/ZMLAHeaderSet", null, null,
					false,
					function (data, response) {
				var TableJSonModel = new sap.ui.model.json.JSONModel();
				// set the odata JSON as data of JSON model
            	TableJSonModel.setData(data);
            //	var a= this.getview().byId("idMLListTable");
            //	a.setModel(TableJSonModel);
            	this.getview().setModel(TableJSonModel, "MLSCRHDATA");	
            //	console.log(data);
			});*/
			var TableJSonModel = new sap.ui.model.json.JSONModel("model/Data.json");
			TableJSonModel.loadData("model/Data.json");
			this.getView().setModel(TableJSonModel, "HRDDETAIL");

			this.mGroupFunctions = {
				Typeoflease: function (oContext) {
					var name = oContext.getProperty("Typeoflease");
					return {
						key: name,
						text: name
					};
				},
				Currency: function (oContext) {
					var name = oContext.getProperty("Currency");
					return {
						key: name,
						text: name
					};
					//var currencyCode = oContext.getProperty("CurrencyCode");
					/*var key, text;
					if (Currency_COde === "USD") {
						key = "CurrencyCode";
						text = "USD";
					} /*else if (price <= 1000) {
						key = "BT100-1000";
						text = "Between 100 and 1000 " + currencyCode;
					} else {
						key = "GT1000";
						text = "More than 1000 " + currencyCode;
					}*/
					/*return {
						key: key,
						text: text
					};*/
				}
			};

		},

		//Reset Search Data starts

		onResetHdrList: function (oEvent) {
			this.getView().byId("idMlLeaseAgre").setValue("");
			this.getView().byId("idCompamyCode").setValue("");
			this.getView().byId("idTypeOfLease").setValue("");
			this.getView().byId("idStartDateFromdate").setValue("");
			this.getView().byId("idVendor").setValue("");
			this.getView().byId("idEndDateFromdate").setValue("");
			this.fuHeaderDetails();
		},

		//Reset Search Data Ends

		fuHeaderDetails: function () {
			var Model = this.getOwnerComponent().getModel("leaseAgg");
			Model.read("/HeaderSet", {
				success: jQuery.proxy(this._fnHandleSuccessObjectRead, this),
				error: jQuery.proxy(this._fnHandleErrorObjectRead, this)
			});
		},

		_fnHandleSuccessObjectRead: function (oData, oResponse) {
			var TableJSonModel = new sap.ui.model.json.JSONModel();
			var LeaseAgNoJSonModel = new sap.ui.model.json.JSONModel();
			TableJSonModel.setData(oData);
			LeaseAgNoJSonModel.setData(oData);
			//	this.getView().byId("idMLListTable").setModel(TableJSonModel, "MLSCRHDATA");
			this.getView().setModel(TableJSonModel, "MLSCRHDATA");

		},
		fnCreate: function (oEvent) {
			/*var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("create_edit_display");*/
			//working

			var TableJSonModel = new sap.ui.model.json.JSONModel("model/Data.json");
			TableJSonModel.loadData("model/Data.json");
			this.getView().setModel(TableJSonModel, "HRDDETAIL");

			this.getView().byId("idTitle").setTitle("Create Aggrement");
			this.getView().getModel("lVisEnb").getData().isVisibleLease = false;
			this.getView().getModel("lVisEnb").getData().isVisibleCrLease = true;
			this.getView().getModel("lVisEnb").getData().isEnableLease = true;
			this.getView().getModel("lVisEnb").getData().isEnableLeaseItem = true;
			this.getView().getModel("lVisEnb").refresh();
			this.getView().byId("idEditDetailsBtn").setVisible(false);
			//working ends

			/*this.getView().byId("idTitle").setTitle("Create Aggrement");
			this.getView().byId("idHeader1").setVisible(false);
			this.getView().byId("idHeader2").setVisible(true);

			this.getView().byId("idForButtons").setVisible(false);
			this.getView().byId("idMLListTableCreate").setVisible(true);
			this.getView().byId("idMLListTable").setVisible(false);
			this.getView().byId("idCreateFooter").setVisible(true);*/

		},

		fnToDetail_Page: function (oEvent) {
			this.getView().byId("idEditDetailsBtn").setVisible(true);
			this.getView().getModel("lVisEnb").getData().isVisibleLease = false;
			this.getView().getModel("lVisEnb").getData().isVisibleCrLease = true;
			this.getView().getModel("lVisEnb").getData().isEnableLease = false;
			this.getView().getModel("lVisEnb").getData().isEnableLeaseItem = false;
			this.getView().getModel("lVisEnb").refresh();

			/*this.getView().byId("idTitle").setTitle("Create Aggrement");
			this.getView().byId("idHeader1").setVisible(false);
			this.getView().byId("idHeader2").setVisible(true);

			this.getView().byId("idForButtons").setVisible(false);
			this.getView().byId("idMLListTableCreate").setVisible(true);
			this.getView().byId("idMLListTable").setVisible(false);
			this.getView().byId("idCreateFooter").setVisible(true);
			this.getView().byId("productInput2").setEnabled(false);*/
			var Model = this.getOwnerComponent().getModel("leaseAgg");
			var spath = oEvent.getSource().getBindingContextPath().split("/")[2];
			var purNo = this.getView().byId("idMLListTable").getModel("MLSCRHDATA").getData().results[spath].Purchasedocnumber;
			//var Model = this.getOwnerComponent().getModel("leaseAgg");
			/*Model.read("/ZMLAHeaderSet('" + purNo + "')/HEADERTOITEM", {
				success: jQuery.proxy(this._fnHandleSuccessObjectDetailRead, this),
				error: jQuery.proxy(this._fnHandleErrorObjectDetailRead, this)*/

			var oPurDocNo = new sap.ui.model.Filter("Purchasedocnumber", sap.ui.model.FilterOperator.EQ, purNo);
			var oDataFilter = new sap.ui.model.Filter({
				filters: [oPurDocNo],
				and: true
			});
			/*	Model.read("/HearderSet", {
				filters: oDataFilter,	
				urlParameters: {$expand: "HEADERTOITEM"},
				success: jQuery.proxy(this._fnHandleSuccessObjectDetailRead, this),
				error: jQuery.proxy(this._fnHandleErrorObjectDetailRead, this) */

			Model.read("/HeaderSet('" + purNo + "')", {
				urlParameters: {
					$expand: "Headertoitem"
				},
				success: jQuery.proxy(this._fnHandleSuccessObjectDetailRead, this),
				error: jQuery.proxy(this._fnHandleErrorObjectDetailRead, this)
			});

			//	HeaderSet('4600000030')?$expand=Headertoitem

			/*	var oParams = {
					"$filter": "Purchasedocnumber eq '" + purNo + "'",
					"$expand": "HEADERTOITEM"
				};
				Model.read("/HearderSet", {
					urlParameters: oParams,
					success: jQuery.proxy(this._fnHandleSuccessObjectDetailRead, this),
					error: jQuery.proxy(this._fnHandleErrorObjectDetailRead, this)
				});*/

			/*	this._navToDetail(purNo);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("detail_agreement");*/

			/*var params = {  
			context : null,  
			async : false,  
			"$filter" : "purchasedocnumber eq '"+purNo + "'",  
			"$expand" : "HEADERTOITEM",
			sorters : null,  
			success: jQuery.proxy(this._fnHandleSuccessObjectDetailRead, this),
			error: jQuery.proxy(this._fnHandleErrorObjectDetailRead, this) 
			};  
			Model.read("/HearderSet", params);*/
		},

		/**
		 * Success handler for constraint read
		 * @param {object} oData     data returned from HTTP request
		 * @param {object} oResponse response returned from HTTP request
		 * @private
		 */
		_fnHandleSuccessObjectDetailRead: function (oData, oResponse) {
			//test
			var aData = {
				"Purchasedocnumber": oData.Purchasedocnumber,
				"Purchasingdoctype": oData.Purchasingdoctype,
				"Currency": oData.Currency,
				"Targetvalue": oData.Targetvalue,
				"Validatystartdate": oData.Validatystartdate,
				"Validatyenddate": oData.Validatyenddate,
				"Agreementdate": oData.Agreementdate,
				"Penalty": oData.Penalty,
				"Bukrs": oData.Companycode,
				"Lifnr": oData.Vendor,
				"Ekgrp": oData.Purchasinggroup,
				"LaType": oData.Typeoflease,
				"Ekorg": oData.Purchaseorg,
				"Headertoitem": []
			};
			/*var a = new sap.ui.model.json.JSONModel(oData);
			var b = new sap.ui.model.json.JSONModel(aData);
			a.setData(b.getData(), true);*/

			for (var i = 0; i < oData.Headertoitem.results.length; i++) {
				var mItemData = {
					"Buyback": oData.Headertoitem.results[i].Buyback,
					"Item": oData.Headertoitem.results[i].Item,
					"Matnr": oData.Headertoitem.results[i].Material,
					//	"Material"			: oData.Headertoitem.results[i].Material,
					"Matkl": oData.Headertoitem.results[i].Materialgroup,
					"Netprice": oData.Headertoitem.results[i].Netprice,
					"Shortetxt": oData.Headertoitem.results[i].Shortetxt,
					"Targetquantity": oData.Headertoitem.results[i].Targetquantity,
					"Unit": oData.Headertoitem.results[i].Unit,
					"Assettype": oData.Headertoitem.results[i].Assettype,
					"Purchasedocnumber": oData.Headertoitem.results[i].Purchasedocnumber,
					//"Materialgroup"		: oData.Headertoitem.results[i].Materialgroup
				};
				aData.Headertoitem.push(mItemData);
				// var c = new sap.ui.model.json.JSONModel(oData);
				//var d = new sap.ui.model.json.JSONModel(ItemData);
				// c.setData(c.getData().Headertoitem.results[i]);
			}

			this.getView().getModel("HEADER").setData(aData, true);
			//this.getView().getModel("HEADER").setProperty("/", a.getData());
			//this.getView().getModel("HEADER").setProperty("/", aData);
			//this.getView().setModel("HEADER", oData);
			this.getView().getModel("HRDDETAIL").setProperty("/lease", aData.Headertoitem);
			//this.getView().getModel("HRDDETAIL").setData(aData.Headertoitem, true);

			/*this.getView().getModel("HRDDETAIL").setProperty("/lease", oData.results);
			this.getView().getModel("HEADER").setProperty("/", oData.results);
			//this.getView().bindProperty("HEADER", "oData");
			this.getView().setModel(oData.results[0].HEADERTOITEM, "HRDDETAIL");*/

			//	this._setClientModel("HRDDETAIL", "/lease", oData);
			//  this._setClientModel("HRDDETAIL", "/lease", oData.results[0].HEADERTOITEM);
			/*delete oData.CapacityItems;
			this._setClientModel("Constraint", "/Header", oData);
            if (this.getModel("data").getProperty("/mode") === "E") {
				this._loadEqnsConvFactors();				
			}*/

		},

		/**
		 * interface to set the client model based on parameters passed
		 * @param {String} sModelName name of model that will be created
		 * @param {String} sEntityName name of set which will contain the dataset provided
		 * @param {Object} oData dataset that needs to be passed to client model
		 * @private
		 */
		_setClientModel: function (sModelName, sEntityName, oData) {
			var oClientModel = this.getView().getModel(sModelName),
				bModelExists = typeof oClientModel === "undefined" ? false : true;
			//If Model doesn't exist on view level then create new one and add data
			if (!bModelExists) {
				oClientModel = new JSONModel();
			}
			//Set data to Model and appropiate property(entityset)
			if (oData.results) {
				oClientModel.setProperty(sEntityName, oData.results);
			} else {
				oClientModel.setProperty(sEntityName, oData);
			}
			//If model model exists on view level then refresh or set model to view
			if (!bModelExists) {
				this.setModel(oClientModel, sModelName);
			}
		},

		fnCopy: function (oEvent) {
			if (this.getView().byId("idMLListTable").getSelectedContextPaths().length === 0) {
				var msg = "Please Select Header";
				MessageToast.show(msg);
			} else {
				this.fnToDetail_Page();
				/*var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var spathSelRow = this.getView().byId("idMLListTable").getSelectedContextPaths()[0].split("/")[2];
				var sSelectedRowdata = this.getView().byId("idMLListTable").getModel("MLSCRHDATA").getData().results[spathSelRow];
				var cmpcode = sSelectedRowdata.Companycode;
				var purOrg = sSelectedRowdata.Purchaseorg;
				var purGrp = sSelectedRowdata.Purchasinggroup;
				var typOflease = sSelectedRowdata.Typeoflease;
				var vendor = sSelectedRowdata.Vendor;
				var penalty = sSelectedRowdata.Penalty;*/

				/*oRouter.navTo("create_edit_display", {
					companyCode: cmpcode,
					purchaseOrg: purOrg,
					purchaseGrp: purGrp,
					tpyeOflease: typOflease,
					vendor: vendor,
					penalty: penalty

				});*/
			}
		},

		fnCopyItem: function (oEvent) {
			var spathSelRow = this.getView().byId("idMLListTableItmDetail").getSelectedIndex();
			var sSelectedRowdata = this.getView().byId("idMLListTableItmDetail").getModel("HRDDETAIL").getData().lease[spathSelRow];

			this.getView().getModel("HRDDETAIL").getProperty("/lease").push(sSelectedRowdata);
			this.getView().getModel("HRDDETAIL").refresh();
		},

		fnFilter: function (oEvent) {
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.Filter_Dialog", this);
				//	this._oPopover.bindElement("/ProductCollection/0");
				this.getView().addDependent(this._oPopover);
			}
			this._oPopover.openBy(oEvent.getSource());
		},

		_navToDetail: function (purNo) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("detail_agreement", {
				PurNo: purNo
			});
		},

		onHeaderUpdateFinshed: function (oEvent) {
			var sTitle = "Header";
			var oTable = this.getView().byId("idMLListTable");
			if (oTable.getBinding("items").isLengthFinal()) {
				var iCount = oEvent.getParameter("total"),
					iItems = oTable.getItems().length;
				sTitle += "(" + iItems + "/" + iCount + ")";
			}
			this.getView().byId("title").setText(sTitle);
		},
		//ValueHelp for Lease Agreement No starts

		fnhandleValueHelpPurAgNo: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("MLSCRHDATA").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_LeaseAgNo",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Purchasedocnumber",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpLeaseAgNoClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},

		//ValueHelp for Lease Agreement No End

		//ValueHelp for Company Code starts
		fnhandleValueHelpCompCode: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("MLSCRHDATA").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_CompanyCode",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Bukrs",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},
		//ValueHelp for Company Code ends

		//Valuehelp Purchasing Group starts

		fnhandleValueHelpPurchGrp: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("HEADER").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_PurchGrp",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Ekgrp",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpPurchGrpClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},

		//Valuehelp Purchasing Group ends

		//Valuehelp Material Starts

		fnhandleValueHelpMaterial: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("HEADER").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_Material",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Matnr",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpMaterialClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				//SetVale for Shortetxt
				//this.getView().byId("__xmlview1--idShortText-__clone92").setValue(oSelectedItem.getDescription());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},
		//Valuehelp Material ends

		//Valuehelp Material Group starts

		fnhandleValueHelpMaterialGrp: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("HEADER").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_MaterialGrp",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Matkl",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpMaterialGrpClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},

		//Valuehelp Material Group ends

		//Valuehelp Vendor starts

		fnhandleValueHelpVendor: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("HEADER").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_Vendor",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Lifnr",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpVendorClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},

		//Valuehelp Vendor ends

		//Valuehelp Purchase Org starts

		fnhandleValueHelpPurchOrg: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			this.getView().getModel("HEADER").getData().ValueHelpSet = this.inputId.split("-")[2];
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_PurchOrg",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Ekorg",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		_handleValueHelpPurchOrgClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			if (this._valueHelpDialog) {
				this._valueHelpDialog.destroy();
				this._valueHelpDialog = null;
			}
		},

		//Valuehelp Purchase Org ends

		fuGet: function (oVal) {
			//var a = oVal;

			/*	this.odataModel.read("/WorkCenterSet", null, null,
					false,
					function (data, response) {
						myData.data = data.results;
						data.results.splice(0, 1);
						oController.WorkcenterModel = new sap.ui.model.json.JSONModel(data);
						for (var i = 0; i < data.results.length; i++) {

							if (data.results[i].Sel === "X") {

								myData.root.push(data.results[i].Objid);
								oController.selcted_wc.push(
									new sap.m.Token({
										key: data.results[i].Objid,
										text: data.results[i].KtextUp
									})

								);
							}
						}
					}); */
			/*var a = oVal;
			oDataModel.read("/TaskListOperationSet", {
			filters: aFilters,
			success: function (oData) {
				this.getView().setBusy(false);
				oModelJson.setData(jQuery.extend({}, oData));
				this.getView().setModel(oModelJson, "oPTaskListModel");
				this.getView().getModel("oPTaskListModel").updateBindings(true);

				this.readOperationTableValues(oVal1, oVal2);
			},
			error: function (oResponse) {
				this.getView().setBusy(false);
				// Handle Error response and display error message to user
				// Read response and display error message
				var sErrMsg = "Error Occurred";
				if (oResponse.responseText) {

					if (jQuery.sap.startsWith(oResponse.responseText, "{\"error\":")) {
						sErrMsg = JSON.parse(oResponse.responseText).error.message.value;
					} else {
						// Retrieve Error Message From XML returned
						sErrMsg = this.getMessageFromXMLResponse(oResponse.responseText);
					}
				}
				this.showMessageToast(sErrMsg);
			}
		});*/
		},
		//Sorting of Table
		fnSortButtonPressed: function (oEvent) {
			var oTable = this.getView().byId("idMLListTable");
			var oItems = oTable.getBinding("items"); // get the table's odata source binding for rows
			//	var oBindingPath = _oView.byId("idProductsTable").getBindingPath("items") + "/0/Name"; // get the sPath related to column clicked
			var oBindingPath = oItems.sPath;
			var bDescending = false;
			var oSorter = new sap.ui.model.Sorter(oBindingPath, bDescending); //create a new sorter for your model based on the column clicked. 
			oItems.sort(oSorter); // push the sorter to your model's binding
		},

		onNavBack: function () {
			this.onPressCancel();
			/*var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = UIComponent.getRouterFor(this);
				oRouter.navTo("RouteApp", {}, true);
			}*/
		},

		//Create functions
		fnAddRow: function (oEvent) {
			/*	var oItemDetails = this.getView().getModel("HRDDETAIL"),
				oData = oItemDetails.getProperty("/lease");*/

			var oItemDetails = this.getView().getModel("HRDDETAIL"),
				oData = oItemDetails.getProperty("/lease");

			oData.push({
				"BuyBack": "",
				"Item": "",
				"Matnr": "",
				"Matkl": "",
				"NetPrice": "",
				"ShortText": "",
				"TargetQuality": "",
				"Unit": "",
				"Assettype": "",
				"Purchasedocnumber": ""
			});
			oItemDetails.refresh();
			oItemDetails = this.getView().getModel("HRDDETAIL");
			var ModelLenght = oItemDetails.getData().lease.length - 1;
			var MaxVal = 0;
			for (var i = 0; i <= oItemDetails.getData().lease.length-1; i++) {
				if (oItemDetails.getData().lease[i].Item > MaxVal) {
					MaxVal = oItemDetails.getData().lease[i].Item;
				}
			
				/*if (i === ModelLenght) {
					var ModelValminOne = oItemDetails.getData().lease[i - 1].Item;
					oItemDetails.getData().lease[i].Item = +ModelValminOne + +10;
					oItemDetails.refresh();
				}*/

			}
			var z = parseInt(MaxVal, 0) + 10;
			var iZero = "000";
               if(z.toString().length === 3){
               	 iZero = "00";
               }else if(z.toString().length === 4){
               	iZero = "0";
               } else if(z.toString().length === 5){
               	iZero = "";
               }
               /*var z = parseInt(MaxVal) + 10;
			var iZero = "00";
               if(MaxVal.length === 3){
               	 iZero = "0";
               }else if(MaxVal.length === 4){
               	iZero = "";
               }
               else if(MaxVal.length === 5){
               	iZero = "000";
               }*/
               
			 oItemDetails.getData().lease[i - 1].Item = iZero + z;

			// oItemDetails.getData().lease[i - 1].Item = +MaxVal + +10;
		//	oItemDetails.getData().lease[i].Item = +ModelValminOne + +10;
					oItemDetails.refresh();
		},

		onPressCreate: function (oEvent) {
			sFlag = true;
			var oDatamodel = this.getView().getModel("HEADER");
			var oDatamodel1 = this.getView().getModel("HRDDETAIL");
			//var requestDataJSON = this.getOwnerComponent().getModel();
			//var reqId = requestDataJSON.getData().viewFormModel[0].CRID;
			//var that = this;
			// Set order header data
			var Header = {};
			Header.Agreementdate = oDatamodel.getData().Agreementdate;
			//Header.Agreementdate = "";
			Header.Companycode = oDatamodel.getData().Bukrs;
			//Header.Companycode = oDatamodel.getData().Companycode;
			Header.Currency = oDatamodel.getData().Currency;
			Header.Purchasedocnumber = oDatamodel.getData().Purchasedocnumber;
			Header.Purchaseorg = oDatamodel.getData().Ekorg;
			Header.Purchasingdoctype = oDatamodel.getData().Purchasingdoctype;
			Header.Purchasinggroup = oDatamodel.getData().Ekgrp;
			Header.Targetvalue = oDatamodel.getData().Targetvalue;
			Header.Typeoflease = oDatamodel.getData().LaType;
			Header.Validatyenddate = oDatamodel.getData().Validatyenddate;
			Header.Validatystartdate = oDatamodel.getData().Validatystartdate;
			Header.Vendor = oDatamodel.getData().Lifnr;
			//Header.Penalty = oDatamodel.getData().Penalty;
			Header.Penalty = "";

			var ReqDetails = [];
			for (var j = 0; j < oDatamodel1.getData().lease.length; j++) {
				ReqDetails.push({
					Assettype: oDatamodel1.getData().lease[j].Assettype,
					//Buyback: oDatamodel1.getData().lease[j].Buyback,
					Buyback: "",
					Item: oDatamodel1.getData().lease[j].Item,
					Material: oDatamodel1.getData().lease[j].Matnr,
					Materialgroup: oDatamodel1.getData().lease[j].Matkl,
					Netprice: oDatamodel1.getData().lease[j].Netprice,
					Purchasedocnumber: oDatamodel1.getData().lease[j].Purchasedocnumber,
					//	Purchasedocnumber: "",
					Shortetxt: oDatamodel1.getData().lease[j].Shortetxt,
					Targetquantity: oDatamodel1.getData().lease[j].Targetquantity,
					Unit: oDatamodel1.getData().lease[j].Unit
				});

			}
			if (Header.Purchasedocnumber === undefined) {
				Header.Purchasedocnumber = "";
			}

			// Link items to the order header
			Header.Headertoitem = ReqDetails;

			var oModel = this.getOwnerComponent().getModel("leaseAgg");

			oModel.create("/HeaderSet", Header, {
				success: jQuery.proxy(this._fnHandleSuccessObjectCreate, this),
				error: jQuery.proxy(this._fnHandleErrorObjectCreate, this)

			});
		},

		_fnHandleSuccessObjectCreate: function (oData, Response) {
			var PrNo = "Agreement " + oData.Purchasedocnumber + " has been Submitted";

			MessageBox.confirm(PrNo, {
				icon: MessageBox.Icon.SUCCESS,
				title: "Success",
				actions: [
					MessageBox.Action.OK
				],
				onClose: jQuery.proxy(this.onPressCancel, this)
					/*onClose : function(oAction) {
					        	   if (oAction === "OK") {
					        	   	this.onPressCancel();
					        		  // this.onNavigationBack();	
					        	   }
					           }*/
			});
		},

		onPressCancel: function () {

			this.getView().byId("idTitle").setTitle("Master Aggrement");
			this.getView().getModel("lVisEnb").getData().isVisibleLease = true;
			this.getView().getModel("lVisEnb").getData().isVisibleCrLease = false;
			this.getView().getModel("lVisEnb").refresh();
			var oModelItem = this.getView().getModel("HRDDETAIL");
			var oModelHdr = this.getView().getModel("HEADER");
			oModelItem.setData({
				lease: {
					"BuyBack": "",
					"Item": "",
					"Matnr": "",
					"Matkl": "",
					"NetPrice": "",
					"ShortText": "",
					"TargetQuality": "",
					"Unit": "",
					"Assettype": "",
					"Purchasedocnumber": ""
				}
			});
			//oModelItem.setData(TableJSonModel);
			oModelHdr.getData().Agreementdate = "";
			oModelHdr.getData().Purchasedocnumber = "";
			//oModelHdr.getData().Companycode = "";
			oModelHdr.getData().Purchasingdoctype = "";
			//oModelHdr.getData().Vendor = "";
			//oModelHdr.getData().Purchaseorg = "";
			//oModelHdr.getData().Purchasinggroup = "";
			oModelHdr.getData().Currency = "";
			oModelHdr.getData().Targetvalue = "";
			oModelHdr.getData().Validatystartdate = "";
			oModelHdr.getData().Validatyenddate = "";
			//oModelHdr.getData().Typeoflease = "";
			oModelHdr.getData().Penalty = "";
			oModelHdr.getData().Bukrs = "";
			oModelHdr.getData().Lifnr = "";
			oModelHdr.getData().Ekgrp = "";
			oModelHdr.getData().LaType = "";
			oModelHdr.getData().Ekorg = "";
			oModelHdr.getData().Bukrs = "";

			/*oModelHdr.setData({
				modelData: {}
			});*/
			oModelItem.updateBindings(true);
			oModelHdr.updateBindings(true);

			if (sFlag === true) {
				this.fuHeaderDetails();
			}

			//this.getView().getModel("lVisEnb").oData.isVisibleLease = false;
			/*this.getView().byId("idTitle").setTitle("Master Aggrement");
			this.getView().byId("idHeader1").setVisible(true);
			this.getView().byId("idHeader2").setVisible(false);

			this.getView().byId("idForButtons").setVisible(true);
			this.getView().byId("idMLListTableCreate").setVisible(false);
			this.getView().byId("idMLListTable").setVisible(true);
			this.getView().byId("idCreateFooter").setVisible(false);*/
		},

		fndeleteRow: function (oEvent) {

			if (this.getView().byId("idMLListTableItmDetail").getSelectedIndices().length === 0) {
				var msg = "Please Select Item to Delete.";
				MessageToast.show(msg);
			} else {

				var oTable = this.getView().byId("idMLListTableItmDetail");
				var oModel = oTable.getModel("HRDDETAIL");
				var oData = oModel.getProperty("/lease");
				var reverse = [].concat(oTable.getSelectedIndices()).reverse();
				reverse.forEach(function (index) {
					oData.splice(index, 1);
				});
				oModel.refresh();
				oTable.setSelectedIndex(-1);
			}
			/*	var oTable = this.getView().byId("idMLListTableCreate");
			var oJSONData = this.getView().getModel("Data");
			var aRows = oJSONData.getData();
			var aContexts = oTable.getSelectedIndices();
			for (var i = aContexts.length - 1; i >= 0; i--) {
				var oThisObj = aContexts[i].getObject();

				var index = $.map(aRows, function (obj, index) {

					if (obj === oThisObj) {
						return index;
					}
				});

				// The splice() method adds/removes items to/from an array
				// Here we are deleting the selected index row
				// https://www.w3schools.com/jsref/jsref_splice.asp

				aRows.splice(index, 1);
			}
*/
			/*		var aSelectedItems = this.getView().byId("idMLListTableCreate").getSelectedIndex();

					for (var i = aSelectedItems.length - 1; i >= 0; i--) { //start with highest index first 
						var oItemContextPath = aSelectedItems[i].getBindingContext().getPath();
						var aPathParts = oItemContextPath.split("/");
						var iIndex = aPathParts[aPathParts.length - 1]; //Index to delete into our array of objects

						var oJSONData = this.getView().getModel().getData();
						oJSONData.correlationData.splice(iIndex, 1); //Use splice to remove your object in the array
						this.getView().getModel().setData(oJSONData); //And set the new data to the model*/
			/*}*/
		},

		fnEditDetails: function () {
			this.getView().getModel("lVisEnb").getData().isEnableLease = false;
			this.getView().getModel("lVisEnb").getData().isEnableLeaseItem = true;
			//this.getView().getModel("lVisEnb").getData().isEnableLease = true;
			this.getView().getModel("lVisEnb").refresh();
			//	sap.ui.getCore().byId("idTrgVal").setEnabled(true);
			//	this.getView().byId("idstartData").setEnabled(true);
			//	this.getView().byId("idenddate").setEnabled(true);
			//	this.getView().byId("idenddate").setEnabled(false);

		},

		onSearchHdrList: function (oEvent) {
			var CompCodeValue;
		},

		//Export Requirement Data
		onDataExport: sap.m.Table.prototype.exportData || function (oEvent) {

			if (!String.prototype.startsWith) {
				String.prototype.startsWith = function (searchString, position) {
					position = position || 0;
					return this.substr(position, searchString.length) === searchString;
				};
			}

			var MJsonModelA = {
				results: []
			};
			Object.entries = Object.entries || function (obj) {
				return Object.keys(obj).map(function (k) {
					return [k, obj[k]];
				});
			};
			var k = 0;
			var ViewModelItms = Object.entries(this.getView().getModel("MLSCRHDATA").getData().results);
			for (var j = 0; j < ViewModelItms.length; j++) {
				MJsonModelA.results[k] = ViewModelItms[j][1];
				k++;
			}
			var MJsonModel = new sap.ui.model.json.JSONModel(MJsonModelA);

			var oExport = new sap.ui.core.util.Export({
				// Type that will be used to generate the content. Own ExportType’s can be created to support other formats
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: ",",
					charset: "utf-8"
				}),
				// Pass in the model created above
				models: MJsonModel,
				// binding information for the rows aggregation
				rows: {
					path: "/results"
				},
				// column definitions with column name and binding info for the content
				columns: [{
						name: "purchasedocnumber",
						template: {
							content: "{purchasedocnumber}"
						}
					}, {
						name: "Validatystartdate",
						template: {
							content: "{Validatystartdate}"
						}
					}, {
						name: "Companycode",
						template: {
							content: "{Companycode}"
						}
					}, {
						name: "Validatyenddate",
						template: {
							content: "{Validatyenddate}"
						}
					}, {
						name: "Penalty",
						template: {
							content: "{Penalty}"
						}
					}, {
						name: "Purchasingdoctype",
						template: {
							content: "{Purchasingdoctype}"
						}
					},
					// Begin of Version 1.1 //
					{
						name: "Vendor",
						template: {
							content: "{Vendor}"
						}
					}, {
						name: "Purchaseorg",
						template: {
							content: "{Purchaseorg}"
						}
					},
					// End of Version 1.1 //
					{
						name: "Purchasinggroup",
						template: {
							content: "{Purchasinggroup}"
						}
					}, {
						name: "Currency",
						template: {
							content: "{Currency}"
						}
					}
				]
			});
			// download exported file
			oExport.saveFile("Demo").catch(function (oError) {
				sap.m.MessageBox.error("Failed" + "\n\n" + oError);
			}).then(function () {
				oExport.destroy();
			});
		},

		handleViewSettingsDialogButtonPressed: function (oEvent) {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.Dialog", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},

		handleConfirm: function (oEvent) {

			var oView = this.getView();
			var oTable = oView.byId("idMLListTable");

			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");

			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;
			var vGroup;
			var aSorters = [];
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				vGroup = this.mGroupFunctions[sPath];
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
			}
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding.sort(aSorters);

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function (i, oItem) {
				var aSplit = oItem.getKey().split("___");
				sPath = aSplit[0];
				/*	var sOperator = aSplit[1];
					var sValue1 = aSplit[2];
					var sValue2 = aSplit[3];*/
				var oFilter = new Filter("Typeoflease", sap.ui.model.FilterOperator.Contains, sPath);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);

			// update filter bar
			/*oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			oView.byId("vsdFilterLabel").setText(mParams.filterString);*/
		},

		onSelectCmpCode: function (oEvent) {
			var aa = oEvent.getParameters().value;

			var a = this.getView().getModel("MLSCRHDATA");
			for (var i = 0; i <= a.oData.results.length; i++) {
				if (a.oData.results[i].Purchasedocnumber === aa) {
					var z = a.oData.results[i].Purchasedocnumber;
				}
			}
		},

		onSearchMLHdrList: function (oEvent) {
			var CompanycodeVal = this.getView().getModel("MLSCRHDATA").getData().Bukrs;
			var PurchasedocNoVal = this.getView().getModel("MLSCRHDATA").getData().Purchasedocnumber;
			var TypeOfLeaseVal = this.getView().getModel("MLSCRHDATA").getData().LaType;
			var VendorVal = this.getView().getModel("MLSCRHDATA").getData().Lifnr;
			var StartDateVal = this.getView().getModel("MLSCRHDATA").getData().Validatystartdate;
			var EndDateVal = this.getView().getModel("MLSCRHDATA").getData().Validatyenddate;
			// var StartDateVal = new Date(this.getView().getModel("MLSCRHDATA").getData().Validatystartdate).toISOString();
			//StartDateVal = "datetime" + "'"+StartDateVal + "'";
			//EndDateVal = "datetime" + "'"+EndDateVal + "'";
			var oTable = this.byId("idMLListTable");
			var oFilters = [];

			/*var oDataFilter = new sap.ui.model.Filter({
				filters: oFilters,
				and: true
			});*/
			if (CompanycodeVal) {
				oFilters = [new Filter("Companycode", FilterOperator.EQ, CompanycodeVal)];
			}
			if (PurchasedocNoVal) {
				oFilters = [new Filter("Purchasedocnumber", FilterOperator.EQ, PurchasedocNoVal)];
			}
			if (VendorVal) {
				oFilters = [new Filter("Vendor", FilterOperator.EQ, VendorVal)];
			}
			if (TypeOfLeaseVal) {
				oFilters = [new Filter("Typeoflease", FilterOperator.EQ, TypeOfLeaseVal)];
			}
			if (StartDateVal) {
				oFilters = [new Filter("Validatystartdate", FilterOperator.EQ, StartDateVal)];
			}
			if (EndDateVal) {
				oFilters = [new Filter("Validatyenddate", FilterOperator.EQ, EndDateVal)];
			}
			/*oFilters = [new Filter("Companycode", FilterOperator.EQ, CompanycodeVal),
	            new Filter("Purchasedocnumber", FilterOperator.EQ, PurchasedocNoVal),
	            new Filter("Vendor", FilterOperator.EQ, VendorVal),
	            new Filter("Typeoflease", FilterOperator.EQ, TypeOfLeaseVal),
	            new Filter("Validatystartdate", FilterOperator.EQ, StartDateVal),
	            new Filter("Validatyenddate", FilterOperator.EQ, EndDateVal)
	        //	new Filter("history", FilterOperator.EQ, History),
	        	// new Filter("globalQuantity", FilterOperator.EQ, Quantity),
	        	// new Filter("dtTpe", FilterOperator.EQ, DtType),
	        //	 new Filter("statusNum", FilterOperator.EQ, DtSatatus),
	            // new Filter("deliveryDtFrm", FilterOperator.EQ, DiliveryDateFrom),
	            // new Filter("deliveryDtTo", FilterOperator.EQ, DiliveryDateTo)
	
	];*/

			var Model = this.getOwnerComponent().getModel("leaseAgg");
			Model.read("/HeaderSet", {
				filters: oFilters,
				success: jQuery.proxy(this._fnHandleSuccessObjectRead, this),
				error: jQuery.proxy(this._fnHandleErrorObjectRead, this)
			});
			// https://webidetesting9849397-b104b2338.dispatcher.us1.hana.ondemand.com/sap/opu/odata/sap/ZECNOMLA_SRV/HeaderSet?$filter=Companycode eq 'LEAS' and Purchasedocnumber eq '4600000134' and Vendor eq '100215' and Typeoflease eq 'OP' and Validatystartdate eq '' and Validatyenddate eq ''

		},
		onChangeMaterialValue: function () {
			var a = 1;
		}

		/*	handleConfirm: function (oEvent) {
			if (oEvent.getSource().getValue()) {
				this.getView().byId("idProductsTable").getBinding("items").filter(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, oEvent.getSource().getValue()),
					new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, oEvent.getSource().getValue())
				], false), "Application");
			}
		}*/

	});
});