sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/UIComponent"
], function (Controller, Filter, JSONModel, UIComponent) {
	"use strict";

	return Controller.extend("masterLeaseAgreement.zMaster_Lease_Agreement.controller.Detail_Agreement", {
		onInit: function () {
		
			//this.getView().setModel("LEASE_DETAIL");
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.getRoute("detail_agreement").attachPatternMatched(this._onRoutePatternMatched, this);

		},

		_onRoutePatternMatched: function (oEvent) {
			
			//this.getView().setProperty("LEASE_DETAIL", "setEnabledFields",false,this)
			var sPurNo = oEvent.getParameter("arguments").PurNo;

			var Model = this.getOwnerComponent().getModel("leaseAgg");
			Model.read("/ZMLAHeaderSet(sPurNo)", {
				success: jQuery.proxy(this._fnHandleSuccessObjectRead, this),
				error: jQuery.proxy(this._fnHandleErrorObjectRead, this)
			});

			//oDataModel = this.getModel();
			//Set the view binding context
			//	sNetworkId = oEvent.getParameter("arguments").networkId;
			/*	oKeyParams = {NetworkId: sNetworkId};
				//TODO To be re-looked during retrofit
				this.getOwnerComponent().oWhenMetadataIsLoaded.then(function () {
					this.getView().bindElement({
						path : oDataModel.createKey("/Networks", oKeyParams)
					});
				}.bind(this));
				//Remove table selections
				this.byId("gdTableObjects").removeSelections(true);
				//Disable add constraint button without any selection
				this.getModel("networkConsAuth").setProperty("/",{
					"addConstraint" : false*/
			/*});*/
		},
		
		_fnHandleSuccessObjectRead : function(oData, oResponse){
				var DetailTableJSonModel = new sap.ui.model.json.JSONModel();
				DetailTableJSonModel.setData(oData);
			//	this.getView().byId("idMLListTable").setModel(TableJSonModel, "Test");
				this.getView().setModel(DetailTableJSonModel, "LEASE_DETAIL");
				
		},
		
			/**
 		 * Error handler for object read operation
 		 * @param {object} oError error data returned from read request
 		 * @private
 		 */
		_fnHandleErrorObjectRead: function(oData, oError) {
			var sErrorResponseText = jQuery.parseJSON(oError.responseText).error.message.value, 
				oResourceBundle = this.getResourceBundle(),
				sErrorText = oResourceBundle.getText("OBJECT_SERVICE_ERROR_TEXT");				
			jQuery.sap.log.error(sErrorText,sErrorResponseText);	
		},

		fnCreate: function (OEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("create_edit_display");
		},

		fnhandleValueHelpCompCode: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"masterLeaseAgreement.zMaster_Lease_Agreement.view.fragments.ValueHelp_CompanyCode",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			/*	this._valueHelpDialog.getBinding("items").filter([new Filter(
					"Name",
					sap.ui.model.FilterOperator.Contains, sInputValue
				)]);*/

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},

		fuGet: function (oVal) {
			/*var a = oVal;
			oDataModel.read("/TaskListOperationSet", {
			filters: aFilters,
			success: function (oData) {
				this.getView().setBusy(false);
				oModelJson.setData(jQuery.extend({}, oData));
				this.getView().setModel(oModelJson, "oPTaskListModel");
				this.getView().getModel("oPTaskListModel").updateBindings(true);

				this.readOperationTableValues(oVal1, oVal2);
			},
			error: function (oResponse) {
				this.getView().setBusy(false);
				// Handle Error response and display error message to user
				// Read response and display error message
				var sErrMsg = "Error Occurred";
				if (oResponse.responseText) {

					if (jQuery.sap.startsWith(oResponse.responseText, "{\"error\":")) {
						sErrMsg = JSON.parse(oResponse.responseText).error.message.value;
					} else {
						// Retrieve Error Message From XML returned
						sErrMsg = this.getMessageFromXMLResponse(oResponse.responseText);
					}
				}
				this.showMessageToast(sErrMsg);
			}
		});*/
		},
		//Sorting of Table
		fnSortButtonPressed: function (oEvent) {
			var oTable = this.getView().byId("idMLListTable");
			var oItems = oTable.getBinding("items"); // get the table's odata source binding for rows
			//	var oBindingPath = _oView.byId("idProductsTable").getBindingPath("items") + "/0/Name"; // get the sPath related to column clicked
			var oBindingPath = "Typeoflease";
			var bDescending = false;
			var oSorter = new sap.ui.model.Sorter(oBindingPath, bDescending); //create a new sorter for your model based on the column clicked. 
			oItems.sort(oSorter); // push the sorter to your model's binding
		},
		
		onNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = UIComponent.getRouterFor(this);
				oRouter.navTo("RouteApp", {}, true);
			}
		}

	});
});