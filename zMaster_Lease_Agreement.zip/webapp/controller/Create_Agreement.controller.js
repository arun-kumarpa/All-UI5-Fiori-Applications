sap.ui.define([
		"jquery.sap.global",
		"sap/ui/core/Fragment",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/UIComponent"
	], function(jQuery, Fragment, Controller, JSONModel, UIComponent) {
	"use strict";

	var PageController = Controller.extend("masterLeaseAgreement.zMaster_Lease_Agreement.controller.Create_Agreement", {

		onInit: function (oEvent) {
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.getRoute("create_edit_display").attachPatternMatched(this._onRoutePatternMatched, this);
		
			// set explored app's demo model on this sample
			/*var oModel = new JSONModel(sap.ui.require.toUrl("sap/ui/demo/mock") + "/supplier.json");
			oModel.attachRequestCompleted(function() {
				this.byId("edit").setEnabled(true);
			}.bind(this));
			this.getView().setModel(oModel);

			this.getView().bindElement("/SupplierCollection/0");

			// Set the initial form to be the display one
			this._showFormFragment("Display");*/
		},
		
		_onRoutePatternMatched: function (oEvent) {
			var scompanyCode = oEvent.getParameter("arguments").companyCode;
			var spurchaseOrg = oEvent.getParameter("arguments").purchaseOrg;
			var spurchaseGrp = oEvent.getParameter("arguments").purchaseGrp;
			//var sversionNumber = oEvent.getParameter("arguments").versionNumber;
			var stpyeOflease = oEvent.getParameter("arguments").tpyeOflease;
			var svendor = oEvent.getParameter("arguments").vendor;
		//	var spenalty = oEvent.getParameter("arguments").penalty;

			this.byId("idCompCode").setValue(scompanyCode);
			this.byId("idPurOrg").setValue(spurchaseOrg);
			this.byId("idPurGrp").setValue(spurchaseGrp);
			//this.byId("idTyplease").setValue(sversionNumber);
			this.byId("idTyplease").setSelectedItemId(stpyeOflease); 
			this.byId("idVendor").setValue(svendor);
		//	this.byId("idPenalty").setValue(spenalty);

			//oDataModel = this.getModel();
			//Set the view binding context
			//	sNetworkId = oEvent.getParameter("arguments").networkId;
			/*	oKeyParams = {NetworkId: sNetworkId};
				//TODO To be re-looked during retrofit
				this.getOwnerComponent().oWhenMetadataIsLoaded.then(function () {
					this.getView().bindElement({
						path : oDataModel.createKey("/Networks", oKeyParams)
					});
				}.bind(this));
				//Remove table selections
				this.byId("gdTableObjects").removeSelections(true);
				//Disable add constraint button without any selection
				this.getModel("networkConsAuth").setProperty("/",{
					"addConstraint" : false*/
			/*});*/
		},
		
	/*	
		*/
	
		
	handleEditPress : function(){
		var oEntityData = {
        "purchasedocnumber": "",
        "Validatystartdate": "\/Date(1556668800000)\/",
        "Companycode": "LEAS",
        "Validatyenddate": "\/Date(1745971200000)\/",
        "Penalty": "",
        "Purchasingdoctype": "",
        "Vendor": "",
        "Purchaseorg": "",
        "Purchasinggroup": "",
        "Currency": "",
        "Typeoflease": ""
       
         };
		
		
				var oModel = this.getOwnerComponent().getModel("leaseAgg");
				oModel.create("/ZMLAHeaderSet", oEntityData, {

			success: jQuery.proxy(function (mResponse) {
				// Set Unsaved Data flag to false
			
			
			}, this),

			error: jQuery.proxy(function (oResponse) {

			})
		});
		},
		

		onExit : function () {
			/*for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName) || this._formFragments[sPropertyName] == null) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}*/
		},

	

		handleCancelPress : function () {

			//Restore the data
		/*	var oModel = this.getView().getModel();
			var oData = oModel.getData();

			oData.SupplierCollection[0] = this._oSupplier;

			oModel.setData(oData);
			this._toggleButtonsAndView(false);*/

		},

		handleSavePress : function () {

			this._toggleButtonsAndView(false);

		},

		_formFragments: {},

		_toggleButtonsAndView : function (bEdit) {
		/*	var oView = this.getView();

			// Show the appropriate action buttons
			oView.byId("edit").setVisible(!bEdit);
			oView.byId("save").setVisible(bEdit);
			oView.byId("cancel").setVisible(bEdit);

			// Set the right form type
			this._showFormFragment(bEdit ? "Change" : "Display");*/
		},

		_getFormFragment: function (sFragmentName) {
		/*	var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "sap.ui.layout.sample.SimpleForm354." + sFragmentName);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];*/
		},

		_showFormFragment : function (sFragmentName) {
			/*var oPage = this.byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));*/
		},
		
		onNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = UIComponent.getRouterFor(this);
				oRouter.navTo("RouteApp", {}, true);
			}
		}

	});


	return PageController;

});