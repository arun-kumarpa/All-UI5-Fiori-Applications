sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		/**
		 * Returns a configuration object for the {@link sap.ushell.ui.footerbar.AddBookMarkButton} "appData" property
		 * @public
		 * @param {string} sTitle the title for the "save as tile" dialog
		 * @returns {object} the configuration object
		 */
		shareTileData: function(sTitle) {
			return {
				title: sTitle
			};
		},
		/**
		 * Returns comment/comments text based on number of comment(s)
		 * @param   {string} sCount No. of comments
		 * @returns {string} Concatenated string as per no. of comments
		 * @private
		 */
		F4Values: function(entityset) {
			
			var sCommentText,
			oResourceBundle = this.getResourceBundle();
			if (typeof entityset === "undefined") {
				entityset = 0;
			}
		  if(entityset <= 1){
				sCommentText = oResourceBundle.getText("COMMENT_COUNT_SINGLE",[entityset]);
			}
		  else {
				sCommentText = oResourceBundle.getText("COMMENT_COUNT_MULTIPLE",[entityset]);
			}
			return sCommentText;

		}

	};

});