sap.ui.define([
	"masterLeaseAgreement/zMaster_Lease_Agreement/test/unit/controller/Master_Agreement.controller"
], function () {
	"use strict";
});