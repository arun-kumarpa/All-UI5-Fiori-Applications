/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"masterLeaseAgreement/zMaster_Lease_Agreement/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"masterLeaseAgreement/zMaster_Lease_Agreement/test/integration/pages/Master_Agreement",
	"masterLeaseAgreement/zMaster_Lease_Agreement/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "masterLeaseAgreement.zMaster_Lease_Agreement.view.",
		autoWait: true
	});
});